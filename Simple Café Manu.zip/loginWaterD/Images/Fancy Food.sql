CREATE DATABASE Fancy_Food;
CREATE TABLE Menu (
  id INT PRIMARY KEY,
  name VARCHAR(20),
  price DECIMAL(10, 2),
  description VARCHAR(100)
);

CREATE TABLE Orders (
  id INT PRIMARY KEY,
  customer_name VARCHAR(100),
  order_date DATE
);

CREATE TABLE OrderItems (
  order_id INT,
  menu_id INT,
  quantity INT,
  FOREIGN KEY (order_id) REFERENCES Orders(id),
  FOREIGN KEY (menu_id) REFERENCES Menu(id)
);


INSERT INTO Menu (id, name, price, description)
VALUES
  (1, 'Cheeseburger', 4.99, 'Juicy beef patty with melted cheese, lettuce, and tomatoes'),
  (2, 'Chicken Nuggets', 3.99, 'Crispy chicken bites served with your choice of dipping sauce');

INSERT INTO Orders (id, customer_name, order_date)
VALUES
  (1, 'John Doe', '2023-09-28'),
  (2, 'Jane Smith', '2023-09-27');

INSERT INTO OrderItems (order_id, menu_id, quantity)
VALUES
  (1, 1, 2),
  (1, 2, 3),
  (2, 2, 1);

  -- Retrieve all menu items
SELECT * FROM Menu;

-- Retrieve menu items with a specific price range
SELECT * FROM Menu WHERE price BETWEEN 4.00 AND 5.00;

-- Retrieve orders and their associated items
SELECT Orders.id, Orders.customer_name, OrderItems.quantity, Menu.name, Menu.price
FROM Orders
JOIN OrderItems ON Orders.id = OrderItems.order_id
JOIN Menu ON OrderItems.menu_id = Menu.id;

-- Update the price of a menu item
UPDATE Menu
SET price = 5.99
WHERE id = 1;

-- Delete a menu item
DELETE FROM Menu WHERE id = 2;

-- Delete an order and its associated items
DELETE FROM Orders WHERE id = 1;
DELETE FROM OrderItems WHERE order_id = 1;
