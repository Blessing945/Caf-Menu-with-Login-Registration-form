<?php
session_start();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username == 'username' && $password == 'password') {
        // Authentication successful
        $_SESSION["username"] = $username;
        echo "Login successful!";
    } else {
        // Authentication failed
        echo "Invalid username or password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <style>

        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;

        }

        body{
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }

        .main{
            position: relative;
            width: 400px;
            height: 400px;
            padding: 60px;
            border-radius: 37% 63% 47% 53% / 26% 27% 73% 74% ;
            box-shadow: 15px 20px 20px rgba(0,0,0,0.07),
            15px 25px 10px rgba(0,0,0,0.05),
            inset 10px 10px 10px rgba(0,0,0,0.08),
            inset -10px -10px 15px rgba(255,255,255,0.651);

        }

        .main span{

            display: flex;
            justify-content: center;
            font-size: 1.7em;
            font-family: Arial, Helvetica, sans-serif;
            font-weight: 700;
            color: rgb(134, 59, 108);

        }

        .main label{
            position: relative;
            top: 20px;
            left: 30px;
            display:  block;
            margin-top: 30px;
            width: 80%;
            padding: 12px;
            border-radius: 40px;
            /*border: 4px solid; */
            padding-left: 15px;
            box-shadow:  inset 10px 10px 10px rgba(0,0,0,0.08),
            15px 20px 20px rgba(0,0,0,0.7);
        }

        .main label input{
            width: 100%;
            height: 30px;
            border: none;
            background: none;
            outline: none;

        }

        .main a{
            position: relative;
            top: 50px;
            left: 125;
            display: flex;
            justify-content: center;
            background: royalblue;
            text-decoration: none;
            padding: 5px;
            width: 65px;
            height: 30px;
            border-radius: 25px;
        }

        .main button{
            position: relative;
            top: 50px;
            bottom: 150px;
            left: 90px;
            display: flex;
            justify-content: center;
            background: royalblue;
            text-decoration: none;
            padding: 5px;
            width: 110px;
            height: 35px;
            border-radius: 25px;
            
        }

        h1.forget{
            font-size: 5px;
        }

        .main h1{
            font-family: Arial, Helvetica, sans-serif;
            font-size: 15px;
        }
    </style>

    <div class="main">
        
        <span>HEY THERE&#128525;</span>
        <form method="welcomePage.php" action="post">
        <label for="">
            <input type="username" placeholder="Enter your username">
        </label>
        <label for="">
            <input type="password" placeholder="Enter Password">
        </label>
        <button type="submit">Login</button>
    </form>
       
    
    </div>
    <div>
    <ol>
        <ul><a href="register.php">Register</a></ul>
        <br>
        <ul><a href="forgotPassword.php">Forgot Password?</a></ul>
    </ol>
</div>
</body>
</html>