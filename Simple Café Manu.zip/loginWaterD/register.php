<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database configuration
    $servername = "localhost";
    $username = "root";
    $password = "@Cyber8001";
    $dbname = "pennycoffee";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve data from the registration form
    $email = $_POST["Email"];
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    // Insert user data into the database
    $sql = "INSERT INTO users (email, username, password) VALUES ('$email', '$username', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful!";
    } else {
        echo "Error: " .$conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registration</title>
    </head>
    <body><!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Registration Form</title>
        </head>
        <body>
            <style>
        
                *{
                    padding: 0;
                    margin: 0;
                    box-sizing: border-box;
        
                }
        
                body{
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    color: white;
                }
        
                .main{
                    position: relative;
                    width: 300;
                    height: 400px;
                    top: 35px;
                    padding: 60px;
                    border-radius: 37% 63% 47% 53% / 26% 27% 73% 74% ;
                    box-shadow: 15px 20px 20px rgba(0,0,0,0.07),
                    15px 25px 10px rgba(0,0,0,0.05),
                    inset 10px 10px 10px rgba(0,0,0,0.08),
                    inset -10px -10px 15px rgba(255,255,255,0.651);
        
                }
        
                .main span{
        
                    display: flex;
                    justify-content: center;
                    font-size: 1.7em;
                    font-family: Arial, Helvetica, sans-serif;
                    font-weight: 900;
                    color: rgb(134, 59, 108);
                    top: -10px;
        
                }
        
                .main label{
                    position: relative;
                    top: -20px;
                    left: 30px;
                    display:  block;
                    margin-top: 30px;
                    width: 80%;
                    padding: 12px;
                    border-radius: 40px;
                    /*border: 4px solid; */
                    padding-left: 15px;
                    box-shadow:  inset 10px 10px 10px rgba(0,0,0,0.08),
                    15px 20px 20px rgba(0,0,0,0.7);
                }
        
                .main label input{
                    width: 100%;
                    height: 30px;
                    border: none;
                    background: none;
                    outline: none;
        
                }
        
                .main a{
                    position: relative;
                    top: 10px;
                    left: 120px;
                    display: flex;
                    justify-content: center;
                    background: royalblue;
                    text-decoration: none;
                    padding: 5px;
                    width: 65px;
                    height: 30px;
                    border-radius: 25px;
                }
                .main button{
            position: relative;
            top: 20px;
            bottom: 150px;
            left: 70px;
            display: flex;
            justify-content: center;
            background: royalblue;
            text-decoration: none;
            padding: 5px;
            width: 110px;
            height: 35px;
            border-radius: 25px;
            
        }
        
                .main a.forget{
                    position: relative;
                    top: 50px;
                    bottom: 150px;
                    left: 300px;
                    display: flex;
                    justify-content: center;
                    background: royalblue;
                    text-decoration: none;
                    padding: 5px;
                    width: 110px;
                    height: 35px;
                    border-radius: 25px;
                    
                }
        
                h1.forget{
                    font-size: 5px;
                }
        
                .main h1{
                    font-family: Arial, Helvetica, sans-serif;
                    font-size: 15px;
                }
            </style>
        
            <div class="main">

                <form action="register.php" method="post">
                <span>REGISTRATION&#128519;</span>
                <label for="">
                    <input type="text" name="Email" placeholder="Enter email">
                </label>
                <label for="">
                    <input type="text" name="username" placeholder="Enter your username">
                </label>
                <label for="">
                    <input type="password" name="password" placeholder="Enter Password">
                </label>
                <button type="submit">Register</button>
            </form>

            </div>
            <div>
            <ol>
                <ul><a href="index.php">Login</a></ul>
                <br>
                <ul><a href="welcomePage.php">Go Back</a></ul>
                
            </ol>
        </div>
        
    </body>
    </html>