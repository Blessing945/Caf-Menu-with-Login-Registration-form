<?php
// Database configuration
    $servername = "localhost";
    $username = "root";
    $password = "@Cyber8001";
    $dbname = "pennycoffee";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Dearest Customer</title>
    <script src="https://unpkg.com/typed.js@2.0.15/dist/typed.umd.js"></script>
</head>
<body>

<style>

    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'poppins' , sans-serif;
    }
    body{
       background-image: url(welcom.jpg);

    }
    .header{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 20px 10%;
        background: transparent;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 100;
    }

    .logo{
        position: relative;
        font-size: relative;
        color: white;
        text-decoration: none;
        font-weight: 600;

    }

    .navbar a{
        display: inline-block;
        font-size: 25px;
        color: white;
        text-decoration: none;
        font-weight: 500;
        margin-left: 35px;
        transition: .3s;
    }

    .navbar a:hover{
        color: #0ef;
    }
    .home{
        position: absolute;
        width: 100%;
        justify-content: space-between;
        height: 120vh;
        background-image: url(welcom.jpg);
        background-size: cover;
        display: flex;
        align-items: center;
        padding: 70px 10% 0;
    }
    .home-content{
        max-width: 600px;
    }
    .home-content h3{
        font-size: 32px;
        font-weight: 400;
      
    
    }
    .home-content h1 {
        font-size: 49px;
        font-weight: 700;
        margin: -3px 0;
    }

    .home-content p{
        font-size: 13px;
        color: white;
        
    }

    .home-sci a{
        display: inline-block;
        justify-content: center;
        width: 40px;
        height: 30px;
        background: transparent;
        border: 2px solid #0ef;
        border-radius: 50%;
        font-size: 20px;
        color: #0ef;
        text-decoration: none;
        margin: 30px 15px 30px 0;
        top: 80px;

    }

    .home-sci a:hover{
        background: #0ef;
        color: #081b29;
        box-shadow:  0 0 20px #0ef;
    }

    .btn-box{
        display: inline-block;
        padding: 12px 28px;
        background: #0ef;
        font-size: 16px;
        color: #081b29;
        border-radius: 40px;
        letter-spacing: 1px;
        text-decoration: none;
        font-weight: 600;
        top: 56px;
    }
    .btn-box:hover{
        box-shadow: 0 0 5px cyan,
        0 0 25px cyan, 0 0 50px cyan,
        0 0 100px cyan, 0 0 200px cyan
    }

    .header{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 20px 10%;
        background: transparent;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 100;
    }

    header .logo{
        position: relative;
        font-size: relative;
        font-weight: 600;
        

    }


</style>
<header>
    <header class="header">
        <a href="#" class="logo">LOGO</a>
</header>
   
    <section class="home">
        <div class="home-content">
            
            <h1>WELCOME TO BLESSING CAFE MENU</h1>
            <br>
            <p>All items shown on our menu is always available.
                <br>If it is not, <br> then we are very sorry to let you know that it is not available at the moment.
            </p> 
            <div class="home-sci">
                <a href=""></a>
               
            </div>
            <a href="index.php" class="btn-box">Login</a>
            <a href="register.php" class="btn-box">Register</a>

        </div>
   

    <script src="script.js"></script>
</body>
</html>